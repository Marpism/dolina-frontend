class CdekApi {
  constructor(options) {
    this._url = options.url
    this._headers = options.headers
  }

  
}