export const EMAIL_REGEXP = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const DEFAULT_COLOR_LIST = [
    {
        "termId": 1057,
        "type": "color",
        "name": "Белый",
        "slug": "white",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "white"
    },
    {
        "termId": 1058,
        "type": "color",
        "name": "Бордовый",
        "slug": "burgundy",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(104, 19, 19)"
    },
    {
        "termId": 1059,
        "type": "color",
        "name": "Голубой",
        "slug": "light-blue",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(185, 239, 243)"
    },
    {
        "termId": 1060,
        "type": "color",
        "name": "Желтый",
        "slug": "yellow",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(255, 255, 137)"
    },
    {
        "termId": 1061,
        "type": "color",
        "name": "Зеленый",
        "slug": "green",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(89, 175, 89)"
    },
    {
        "termId": 1062,
        "type": "color",
        "name": "Коричневый",
        "slug": "brown",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(119, 76, 41)"
    },
    {
        "termId": 1063,
        "type": "color",
        "name": "Красный",
        "slug": "red",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(240, 83, 83)"
    },
    {
        "termId": 1064,
        "type": "color",
        "name": "Оранжевый",
        "slug": "orange",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(241, 131, 68)"
    },
    {
        "termId": 1065,
        "type": "color",
        "name": "Прозрачный",
        "slug": "clear",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(236, 247, 247)"
    },
    {
        "termId": 1067,
        "type": "color",
        "name": "Розовый",
        "slug": "pink",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(253, 208, 216)"
    },
    {
        "termId": 1068,
        "type": "color",
        "name": "Светло-зеленый",
        "slug": "light-green",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(130, 240, 80)"
    },
    {
        "termId": 1069,
        "type": "color",
        "name": "Серый",
        "slug": "gray",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(202, 202, 202)"
    },
    {
        "termId": 1070,
        "type": "color",
        "name": "Синий",
        "slug": "blue",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(82, 133, 243)"
    },
    {
        "termId": 1071,
        "type": "color",
        "name": "Фиолетовый",
        "slug": "purple",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "rgb(166, 109, 219)"
    },
    {
        "termId": 1072,
        "type": "color",
        "name": "Черный",
        "slug": "black",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "black"
    },
    {
        "termId": 1099,
        "type": "color",
        "name": "Разноцветный",
        "slug": "pied",
        "parent": 0,
        "count": null,
        "category_tags": null,
        "extra": "linear-gradient(90deg, rgba(34, 193, 195, 1) 0%, rgba(253, 187, 45, 1) 100%)"
    }
];

export const specialTexts = {
  natural: "Мы работаем только со 100% натуральным камнем! Никаких облагороженных и подкрашенных камней, никаких подделок. Геологическое образование и личная проверка каждого изделия дают нам возможность говорить об этом с уверенностью.",
  masterpiece: "Другого такого же украшения нет и не будет! Мастер сделал его в единственном экземпляре, исходя из индивидуальной красоты конкретного образца камня.",
  iridiscent: "Всю красоту камня с оптическим эффектом никогда не передать на фото и не описать словами. Эффект создаётся при преломлении света в уникальной структуре камня, и может выражаться и благородной световой полосой кошачьего глаза, и волшебно-радужным сиянием иризирующих камней, и ярким искристым блеском. Любите такое? Тогда вам понравятся солнечный и лунный камни, адуляр и лабрадор, кошачий глаз и другие глазковые камни.",
  refund: "Фото не всегда передает истинный облик камня, поэтому нам можно вернуть товар без объяснения причин, если вы получите не то, чего ожидали! А мы с удовольствием поможем вам подобрать именно ваше украшение и именно ваш камень."

}

export const DEFAULT_COLOR_PALETTE = [
    'rgb(210 210 210)',
    'rgb(210 210 210 / 40%)', 
    'rgb(210 210 210 / 90%)', 
    'rgb(210 210 210 / 50%)', 
    'rgb(210 210 210 / 80%)'];

export const FEATURES_LIST = [
    {"slug":"masterpiece", "name": "Авторка"},
    {"slug":"minimalism", "name": "Минималистичное"},
    {"slug":"iridescent", "name": "С переливом"},
    {"slug":"unique", "name": "В единственном экземпляре"},
    {"slug":"star", "name": "Звёздочка"},
];

export const HARDCODED_CATEGORIES = [
    {
        "termId": 40,
        "type": "category",
        "name": "Кольца",
        "slug": "kolca",
        "parent": 0,
        "count": 54,
        "category_tags": "[46,47,581,9,292,476,489,856,62,94,344,51,75,402,378,15,19,921,58,665,78,353,13,72,56,70,876,82,1036,1042,398,1043,89,39,150,499,315,447,359,53,144]",
        "extra": null
    },
    {
        "termId": 6,
        "type": "category",
        "name": "Бусы",
        "slug": "busy",
        "parent": 0,
        "count": 41,
        "category_tags": "[19,38,23,767,32,62,768,70,9,22,24,33,126,39,51,67,132,82,402,81,13,105,78,447,348,1026,239,292,378,512,815,72,773,401,760]",
        "extra": null
    },
    {
        "termId": 44,
        "type": "category",
        "name": "Серьги",
        "slug": "sergi",
        "parent": 0,
        "count": 40,
        "category_tags": "[46,47,581,9,292,476,489,105,353,378,62,344,348,51,19,921,876,58,665,829,78,21,1029,82,1036,359,398,53,150,402,56,144]",
        "extra": null
    },
    {
        "termId": 102,
        "type": "category",
        "name": "Подвески",
        "slug": "podveski",
        "parent": 0,
        "count": 36,
        "category_tags": "[313,105,581,46,353,378,489,70,315,104,999,78,19,292,921,1003,38,72,773,1049,876,829,830,359,58,126,53,402,150]",
        "extra": null
    },
    {
        "termId": 167,
        "type": "category",
        "name": "Комплекты",
        "slug": "komplekty",
        "parent": 0,
        "count": 24,
        "category_tags": "[46,47,581,9,292,476,489,105,62,344,51,378,19,921,58,665,353,78,82,1036,359,53,150,402,56]",
        "extra": null
    },
    {
        "termId": 25,
        "type": "category",
        "name": "Браслеты",
        "slug": "braslety",
        "parent": 0,
        "count": 14,
        "category_tags": "[27,72,58,665,19,921,1010,126,53,150,94,359,62]",
        "extra": null
    },
    {
        "termId": 28,
        "type": "category",
        "name": "Колье",
        "slug": "kole",
        "parent": 0,
        "count": 4,
        "category_tags": "[9,19,22,23,38,39,51,62,67,402,13,105]",
        "extra": null
    },
    {
        "termId": 107,
        "type": "category",
        "name": "Броши",
        "slug": "broshi",
        "parent": 0,
        "count": 2,
        "category_tags": "[78]",
        "extra": null
    }
]